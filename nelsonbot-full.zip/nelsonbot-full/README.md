# NelsonBot

NelsonBot is a pediatric chatbot application built with React (frontend) and Express (backend), using TypeScript for the frontend and JavaScript for the backend. It integrates with Supabase for data storage and retrieval.

## Project Structure

