import React from 'react';
import { Layout } from './components/Layout';

const App: React.FC = () => {
  return (
    <Layout />
  );
};

export default App;

