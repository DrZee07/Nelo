export interface Topic {
  id: number;
  title: string;
  content: string;
  tags: string[];
}

